import 'package:flutter/material.dart';
import 'package:project/core/routes/app_routes.dart';
import 'package:project/core/theme/app_theme.dart';
import 'package:project/models/focus_task.dart';
import 'package:project/services/my_time_store.dart';
import 'package:project/shared/widgets/app_bottom_navigation.dart';
import 'package:project/shared/widgets/app_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = MyTimeStore.instance;

    return Scaffold(
      drawer: const _DashboardDrawer(),
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            tooltip: 'Open menu',
            onPressed: () => Scaffold.of(context).openDrawer(),
            icon: const Icon(Icons.menu_rounded),
          ),
        ),
        title: const Text('MyTime'),
        actions: [
          IconButton(
            onPressed: () =>
                Navigator.pushNamed(context, AppRoutes.notifications),
            icon: const Icon(Icons.notifications),
          ),
          IconButton(
            onPressed: () => Navigator.pushNamed(context, AppRoutes.settings),
            icon: const Icon(Icons.settings),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: store,
        builder: (context, child) {
          final task = store.selectedTask;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const _HomeGreeting(),
              const SizedBox(height: 18),
              _TodayProgressCard(
                totalFocusTime: _formatMinutes(store.totalFocusSeconds),
                sessions: store.sessions.length,
                completedTasks: store.completedTaskCount,
                totalTasks: store.tasks.length,
              ),
              const SizedBox(height: 24),
              _UpcomingTasksSection(
                tasks: store.tasks,
                onViewAll: () => Navigator.pushNamed(context, AppRoutes.tasks),
                onOpen: (task) {
                  MyTimeStore.instance.selectTask(task);
                  Navigator.pushNamed(context, AppRoutes.taskDetail);
                },
                onToggleCompleted: (task) {
                  MyTimeStore.instance.setTaskCompleted(
                    task,
                    !task.isCompleted,
                  );
                },
              ),
              const SizedBox(height: 24),
              if (task != null) _CurrentFocusCard(task: task),
              if (task == null)
                _EmptyTaskCard(
                  onCreate: () =>
                      Navigator.pushNamed(context, AppRoutes.addTask),
                ),
            ],
          );
        },
      ),
      bottomNavigationBar: const AppBottomNavigation(selectedIndex: 0),
    );
  }
}

class _DashboardDrawer extends StatelessWidget {
  const _DashboardDrawer();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scene = theme.extension<AppSceneTheme>()!;

    return Drawer(
      width: MediaQuery.sizeOf(context).width * 0.82,
      backgroundColor: theme.drawerTheme.backgroundColor,
      shape: theme.drawerTheme.shape,
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
          children: [
            Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: scene.navGlow,
                        blurRadius: 18,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.timer, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'MyTime',
                    style: theme.textTheme.headlineSmall?.copyWith(
                      color: theme.colorScheme.primary,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _DrawerMenuCard(
              children: [
                _DrawerTile(
                  icon: Icons.dashboard_outlined,
                  label: 'Dashboard',
                  color: theme.colorScheme.primary,
                  onTap: () => Navigator.pop(context),
                ),
                _DrawerTile(
                  icon: Icons.checklist_outlined,
                  label: 'Tasks',
                  color: theme.colorScheme.primary,
                  onTap: () => _replaceWith(context, AppRoutes.tasks),
                ),
                _DrawerTile(
                  icon: Icons.add_task_outlined,
                  label: 'Create task',
                  color: theme.colorScheme.secondary,
                  onTap: () => _push(context, AppRoutes.addTask),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _DrawerMenuCard(
              children: [
                _DrawerTile(
                  icon: Icons.timer_outlined,
                  label: 'Focus Time',
                  color: theme.colorScheme.primary,
                  onTap: () => _replaceWith(context, AppRoutes.focus),
                ),
                _DrawerTile(
                  icon: Icons.bar_chart_outlined,
                  label: 'Statistics',
                  color: theme.colorScheme.primary.withValues(alpha: 0.76),
                  onTap: () => _replaceWith(context, AppRoutes.statistics),
                ),
                _DrawerTile(
                  icon: Icons.calendar_month_outlined,
                  label: 'Calendar',
                  color: theme.colorScheme.secondary,
                  onTap: () => _push(context, AppRoutes.calendar),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _DrawerMenuCard(
              children: [
                _DrawerTile(
                  icon: Icons.notifications_outlined,
                  label: 'Notifications',
                  color: theme.colorScheme.primary,
                  onTap: () => _push(context, AppRoutes.notifications),
                ),
                _DrawerTile(
                  icon: Icons.settings_outlined,
                  label: 'Settings',
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.74),
                  onTap: () => _push(context, AppRoutes.settings),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _replaceWith(BuildContext context, String route) {
    Navigator.pop(context);
    Navigator.pushReplacementNamed(context, route);
  }

  void _push(BuildContext context, String route) {
    Navigator.pop(context);
    Navigator.pushNamed(context, route);
  }
}

class _DrawerMenuCard extends StatelessWidget {
  const _DrawerMenuCard({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(children: children),
    );
  }
}

class _DrawerTile extends StatelessWidget {
  const _DrawerTile({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListTile(
      minLeadingWidth: 24,
      leading: Icon(icon, color: color),
      title: Text(
        label,
        style: theme.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w700,
        ),
      ),
      trailing: Icon(
        Icons.chevron_right,
        color: theme.colorScheme.onSurface.withValues(alpha: 0.42),
      ),
      onTap: onTap,
    );
  }
}

class _HomeGreeting extends StatelessWidget {
  const _HomeGreeting();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scene = theme.extension<AppSceneTheme>()!;

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Hello, Student', style: theme.textTheme.headlineSmall),
              const SizedBox(height: 4),
              Text(
                "Let's make today productive!",
                style: theme.textTheme.bodyMedium,
              ),
            ],
          ),
        ),
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            color: theme.colorScheme.surface.withValues(
              alpha: theme.brightness == Brightness.dark ? 0.72 : 0.92,
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: scene.cardBorder),
            boxShadow: [
              BoxShadow(
                color: scene.navGlow,
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Icon(scene.accentIcon, color: theme.colorScheme.primary),
        ),
      ],
    );
  }
}

class _TodayProgressCard extends StatelessWidget {
  const _TodayProgressCard({
    required this.totalFocusTime,
    required this.sessions,
    required this.completedTasks,
    required this.totalTasks,
  });

  final String totalFocusTime;
  final int sessions;
  final int completedTasks;
  final int totalTasks;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final percent = totalTasks == 0 ? 0.0 : completedTasks / totalTasks;

    return AppCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Today's Progress",
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              SizedBox(
                width: 112,
                height: 112,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 104,
                      height: 104,
                      child: CircularProgressIndicator(
                        value: percent.clamp(0.0, 1.0),
                        strokeWidth: 12,
                        color: theme.colorScheme.primary,
                        backgroundColor: theme.colorScheme.secondary.withValues(
                          alpha: 0.18,
                        ),
                        strokeCap: StrokeCap.round,
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '${(percent * 100).round()}%',
                          style: theme.textTheme.headlineSmall,
                        ),
                        Text('Focused', style: theme.textTheme.bodySmall),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  children: [
                    _ProgressMetric(
                      label: 'Focus Time',
                      value: totalFocusTime,
                      color: theme.colorScheme.primary,
                    ),
                    const SizedBox(height: 12),
                    _ProgressMetric(
                      label: 'Tasks Done',
                      value: '$completedTasks/$totalTasks',
                      color: theme.colorScheme.secondary,
                    ),
                    const SizedBox(height: 12),
                    _ProgressMetric(
                      label: 'Sessions',
                      value: '$sessions',
                      color: theme.colorScheme.primary.withValues(alpha: 0.76),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ProgressMetric extends StatelessWidget {
  const _ProgressMetric({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(label, style: theme.textTheme.bodySmall)),
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

class _UpcomingTasksSection extends StatelessWidget {
  const _UpcomingTasksSection({
    required this.tasks,
    required this.onViewAll,
    required this.onOpen,
    required this.onToggleCompleted,
  });

  final List<FocusTask> tasks;
  final VoidCallback onViewAll;
  final ValueChanged<FocusTask> onOpen;
  final ValueChanged<FocusTask> onToggleCompleted;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final upcoming = [...tasks]
      ..sort((first, second) {
        if (first.isCompleted != second.isCompleted) {
          return first.isCompleted ? 1 : -1;
        }
        return first.scheduledDate.compareTo(second.scheduledDate);
      });
    final visibleTasks = upcoming.take(3).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text('Upcoming Tasks', style: theme.textTheme.titleLarge),
            ),
            TextButton(onPressed: onViewAll, child: const Text('View all')),
          ],
        ),
        const SizedBox(height: 10),
        if (visibleTasks.isEmpty)
          AppCard(
            child: Row(
              children: [
                Icon(
                  Icons.check_circle_rounded,
                  color: theme.colorScheme.secondary,
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text('No upcoming tasks. Enjoy the quiet.'),
                ),
              ],
            ),
          )
        else
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              children: [
                for (final task in visibleTasks)
                  _UpcomingTaskTile(
                    task: task,
                    onTap: () => onOpen(task),
                    onToggleCompleted: () => onToggleCompleted(task),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

class _UpcomingTaskTile extends StatelessWidget {
  const _UpcomingTaskTile({
    required this.task,
    required this.onTap,
    required this.onToggleCompleted,
  });

  final FocusTask task;
  final VoidCallback onTap;
  final VoidCallback onToggleCompleted;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(
          color: _priorityColor(theme, task.priority),
          shape: BoxShape.circle,
        ),
      ),
      title: Text(
        task.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: theme.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w800,
          decoration: task.isCompleted
              ? TextDecoration.lineThrough
              : TextDecoration.none,
          color: task.isCompleted
              ? theme.colorScheme.onSurface.withValues(alpha: 0.52)
              : theme.colorScheme.onSurface,
        ),
      ),
      subtitle: Text(
        '${_formatDate(task.scheduledDate)} · ${task.focusMinutes} min',
        style: theme.textTheme.bodyMedium?.copyWith(
          color: task.isCompleted
              ? theme.colorScheme.onSurface.withValues(alpha: 0.45)
              : null,
        ),
      ),
      trailing: InkWell(
        onTap: onToggleCompleted,
        borderRadius: BorderRadius.circular(999),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: task.isCompleted
                ? theme.colorScheme.primary
                : Colors.transparent,
            shape: BoxShape.circle,
            border: Border.all(
              color: task.isCompleted
                  ? theme.colorScheme.primary
                  : theme.colorScheme.primary.withValues(alpha: 0.55),
              width: 1.6,
            ),
          ),
          child: Icon(
            Icons.check_rounded,
            size: 16,
            color: task.isCompleted ? Colors.white : Colors.transparent,
          ),
        ),
      ),
    );
  }

  Color _priorityColor(ThemeData theme, TaskPriority priority) {
    switch (priority) {
      case TaskPriority.high:
        return theme.colorScheme.error;
      case TaskPriority.medium:
        return theme.colorScheme.primary;
      case TaskPriority.low:
        return theme.colorScheme.secondary;
    }
  }
}

class _CurrentFocusCard extends StatefulWidget {
  const _CurrentFocusCard({required this.task});

  final FocusTask task;

  @override
  State<_CurrentFocusCard> createState() => _CurrentFocusCardState();
}

class _CurrentFocusCardState extends State<_CurrentFocusCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scene = theme.extension<AppSceneTheme>()!;
    final task = widget.task;
    final progress = task.outputs.isEmpty
        ? 0.0
        : task.completedOutputCount / task.outputs.length;
    final canStart = task.canStartToday;
    final outputs = task.outputs.take(3).toList();

    return AppCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: scene.navGlow,
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: const Icon(Icons.flag_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleLarge,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${task.focusMinutes} min • ${task.completedOutputCount}/${task.outputs.length} outputs',
                      style: theme.textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: _expanded ? 'Hide details' : 'Show details',
                onPressed: () {
                  setState(() => _expanded = !_expanded);
                },
                icon: Icon(
                  _expanded
                      ? Icons.keyboard_arrow_up_rounded
                      : Icons.keyboard_arrow_down_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _MiniBadge(
                icon: canStart
                    ? Icons.play_circle_outline
                    : Icons.event_available_outlined,
                label: canStart ? 'Ready' : 'Plan',
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 8,
                    color: theme.colorScheme.primary,
                    backgroundColor: theme.colorScheme.secondary.withValues(
                      alpha: 0.20,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                '${(progress * 100).round()}%',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.colorScheme.primary,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          if (_expanded) ...[
            const SizedBox(height: 14),
            Text(task.description, style: theme.textTheme.bodyMedium),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _TaskMetaChip(
                  icon: Icons.timer_outlined,
                  label: '${task.focusMinutes} min',
                ),
                _TaskMetaChip(
                  icon: Icons.check_circle_outline,
                  label:
                      '${task.completedOutputCount}/${task.outputs.length} output',
                ),
                _TaskMetaChip(
                  icon: Icons.event_outlined,
                  label: _formatDate(task.scheduledDate),
                ),
                _TaskMetaChip(
                  icon: Icons.repeat_rounded,
                  label: _repeatText(task.repeat),
                ),
                if (task.reminderEnabled)
                  _TaskMetaChip(
                    icon: Icons.notifications_active_outlined,
                    label: task.reminderTime,
                  ),
              ],
            ),
            if (outputs.isNotEmpty) ...[
              const SizedBox(height: 14),
              ...outputs.map((output) => _OutputPreviewRow(output: output)),
            ],
            const SizedBox(height: 14),
          ],
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: task.isCompleted || !canStart
                  ? null
                  : () {
                      MyTimeStore.instance.startTask(task);
                      Navigator.pushNamed(context, AppRoutes.focus);
                    },
              icon: const Icon(Icons.play_arrow_rounded),
              label: Text(
                task.isCompleted
                    ? 'Completed'
                    : canStart
                    ? 'Focus on this task'
                    : 'Available on ${_formatDate(task.scheduledDate)}',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniBadge extends StatelessWidget {
  const _MiniBadge({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scene = theme.extension<AppSceneTheme>()!;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(
          alpha: theme.brightness == Brightness.dark ? 0.70 : 0.92,
        ),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: scene.cardBorder),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: theme.colorScheme.primary),
          const SizedBox(width: 5),
          Text(
            label,
            style: theme.textTheme.labelLarge?.copyWith(
              color: theme.colorScheme.primary,
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskMetaChip extends StatelessWidget {
  const _TaskMetaChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(
          alpha: theme.brightness == Brightness.dark ? 0.58 : 0.78,
        ),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: theme.colorScheme.primary),
          const SizedBox(width: 6),
          Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _OutputPreviewRow extends StatelessWidget {
  const _OutputPreviewRow({required this.output});

  final FocusOutput output;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: output.isCompleted
            ? theme.colorScheme.secondary.withValues(alpha: 0.14)
            : theme.colorScheme.surface.withValues(
                alpha: theme.brightness == Brightness.dark ? 0.60 : 0.88,
              ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: output.isCompleted
              ? theme.colorScheme.secondary.withValues(alpha: 0.34)
              : theme.dividerColor,
        ),
      ),
      child: Row(
        children: [
          Icon(
            output.isCompleted
                ? Icons.check_circle_rounded
                : Icons.radio_button_unchecked_rounded,
            color: output.isCompleted
                ? theme.colorScheme.secondary
                : theme.colorScheme.onSurface.withValues(alpha: 0.42),
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              output.title,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: output.isCompleted
                    ? theme.colorScheme.onSurface.withValues(alpha: 0.74)
                    : theme.colorScheme.onSurface,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyTaskCard extends StatelessWidget {
  const _EmptyTaskCard({required this.onCreate});

  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        children: [
          const Text('There is no task available for focus.'),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: onCreate, child: const Text('Create task')),
        ],
      ),
    );
  }
}

String _formatMinutes(int seconds) {
  if (seconds < 60) return '${seconds}s';
  return '${seconds ~/ 60}m';
}

String _formatDate(DateTime date) {
  return '${date.month.toString().padLeft(2, '0')}/'
      '${date.day.toString().padLeft(2, '0')}/${date.year}';
}

String _repeatText(TaskRepeat repeat) {
  switch (repeat) {
    case TaskRepeat.none:
      return 'No repeat';
    case TaskRepeat.daily:
      return 'Daily';
    case TaskRepeat.weekly:
      return 'Weekly';
    case TaskRepeat.monthly:
      return 'Monthly';
  }
}
